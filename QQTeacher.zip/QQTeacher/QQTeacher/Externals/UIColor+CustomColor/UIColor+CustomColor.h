//
//  UIColor+CustomColor.h
//  QQStudent
//
//  Created by lynn on 14-2-20.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (CustomColor)
+ (UIColor *) colorWithHexString: (NSString *)color;
@end
