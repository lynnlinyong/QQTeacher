//
//  CLog.h
//  Financialplanner
//
//  Created by jsetc on 12-8-31.
//  Copyright 2012年 seed. All rights reserved.
//

#ifdef DEBUG
#define CLog(fmat, ...) NSLog((DEBUG_PREFIX fmat), ##__VA_ARGS__);
#else
#define CLog(fmat, ...)
#endif