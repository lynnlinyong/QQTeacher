//
//  UpdatePhoneViewController.h
//  QQStudent
//
//  Created by lynn on 14-2-16.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdatePhoneViewController : UIViewController<UITextFieldDelegate>
{
    UITextField  *txtFld;
    UIButton     *okBtn;
}
@property (nonatomic, retain) NSString *phone;
@end
