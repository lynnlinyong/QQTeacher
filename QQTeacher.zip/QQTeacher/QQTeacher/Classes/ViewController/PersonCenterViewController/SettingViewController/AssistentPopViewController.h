//
//  AssistentPopViewController.h
//  QQTeacher
//
//  Created by Lynn on 14-3-17.
//  Copyright (c) 2014年 Lynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssistentPopViewController : UIViewController
@property (nonatomic, copy) NSDictionary *applyDic;
@end
