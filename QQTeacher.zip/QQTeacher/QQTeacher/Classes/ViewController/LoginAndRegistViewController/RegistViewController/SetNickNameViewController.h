//
//  SetNickNameViewController.h
//  QQStudent
//
//  Created by lynn on 14-2-4.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetNickNameViewController : UIViewController<UITextFieldDelegate>
{
    UITextField   *nickNameFld;
    UIButton *okBtn;
    float originY;
}
@property (nonatomic, retain) NSString *name;
@end
