//
//  CallOutAnnotationView.h
//  QQStudent
//
//  Created by lynn on 14-2-7.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import <MAMapKit/MAMapKit.h>

@interface CallOutAnnotationView : MAAnnotationView
@property(nonatomic,retain) UIView *contentView;
@end
