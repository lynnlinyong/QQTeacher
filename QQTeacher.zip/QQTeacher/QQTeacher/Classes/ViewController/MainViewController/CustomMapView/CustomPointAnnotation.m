//
//  CustomPointAnnotation.m
//  QQStudent
//
//  Created by lynn on 14-2-8.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import "CustomPointAnnotation.h"

@implementation CustomPointAnnotation
@synthesize student;
@synthesize tag;
@synthesize siteObj;

@end
