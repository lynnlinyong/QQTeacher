//
//  NoticeWallViewController.h
//  QQStudent
//
//  Created by lynn on 14-3-4.
//  Copyright (c) 2014年 lynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoticeWallViewController : UIViewController
@property (nonatomic, copy) NSString  *title;
@property (nonatomic, copy) NSString  *content;
@end
